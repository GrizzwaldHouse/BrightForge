#!/usr/bin/env bash
# Find the commit that broke a command. Usage: bisect_regression.sh GOOD_SHA "TEST COMMAND" [BAD_SHA=HEAD]
# Runs in a throwaway worktree so the working tree is untouched. Prints the first bad commit.
set -u
GOOD=$1; CMD=$2; BAD=${3:-HEAD}
ROOT=$(git rev-parse --show-toplevel); TMP=$(mktemp -d)
git worktree add --detach "$TMP" "$BAD" >/dev/null 2>&1 || exit 1
[ -d "$ROOT/node_modules" ] && ln -s "$ROOT/node_modules" "$TMP/node_modules"
cd "$TMP" && git bisect start "$BAD" "$GOOD" >/dev/null && git bisect run bash -c "$CMD" | tail -12
RES=$(git bisect log | tail -1); git bisect reset >/dev/null 2>&1; cd "$ROOT"; git worktree remove --force "$TMP"; echo "$RES"
