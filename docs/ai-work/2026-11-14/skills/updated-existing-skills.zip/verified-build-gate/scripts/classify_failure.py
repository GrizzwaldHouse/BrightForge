#!/usr/bin/env python3
"""Classify a failing gate step from its log using the repair catalogue (references/repair-catalogue.json).

Usage: classify_failure.py LOGFILE [--was-passing]
Prints JSON {class, cause, repair, matched}. --was-passing marks a test that passed before and now
times out or fails (class UNEXPLAINED until investigated). Deterministic: the catalogue is data, so a
small model only has to apply the suggested repair.
"""
import json, os, re, sys

here = os.path.dirname(os.path.abspath(__file__))
cat = json.load(open(os.path.join(here, "..", "references", "repair-catalogue.json")))
text = open(sys.argv[1], encoding="utf-8", errors="replace").read()
was_passing = "--was-passing" in sys.argv
for e in cat["entries"]:
    if re.search(e["pattern"], text, re.I | re.S):
        print(json.dumps({"class": e["class"], "cause": e["cause"], "repair": e["repair"], "matched": e["id"]}, indent=1))
        sys.exit(0)
cls = "UNEXPLAINED" if was_passing else "PRODUCT"
print(json.dumps({"class": cls, "cause": "no catalogue match",
                  "repair": cat["default_repair"][cls], "matched": None}, indent=1))
