---
name: verified-build-gate
description: "6-step build verification pipeline that prevents unstable code from being pushed, with a built-in repair loop. Runs: build, launch runtime, 5-minute stability monitor, full test suite, independent reviewer agent, and produces a final READY/NOT READY verdict. Use it as the definition of done: after integrating or merging branches, whenever a subagent returns code, before pushing, before saying work is finished, and before writing a handoff. Also use when pushing code, before releases, or when /build-gate is invoked. Use it when a project has no build script or Vitest/Playwright setup (map the steps to what exists), when running unproven code in an offline container sandbox, and whenever a gate step fails: classify the failure, fix it and re-run only the failed steps instead of reporting it."
user-invocable: true
allowed-tools:
- Bash
- Read
- Grep
- Glob
---

# Verified Build Gate

> Prevents unstable or unverified builds from being marked as complete or pushed to the repository.

## When to Use

- Before `git push` (auto-triggered by pre-push hook in quick mode)
- Before releases or deployments (run full mode manually)
- When `/build-gate` is invoked
- After significant refactoring or dependency changes

## Pipeline (6 Steps)

### Step 1: BUILD
Run the project's build command. Any compile-time error = immediate FAIL.
```bash
npm run build
```

### Step 2: LAUNCH RUNTIME
Start the application and wait for it to respond on its health endpoint.
- Timeout: 60s (full) / 30s (quick)
- Failure: crash, freeze, or no health response within timeout

### Step 3: STABILITY MONITOR (5 min) [full mode only]
Monitor the running application for 5 minutes:
- Subscribe to SSE event stream (Observer pattern, NOT polling)
- Health check every 30 seconds
- Watch for: unhandled errors, memory growth >50%, SSE disconnections
- Any anomaly = immediate FAIL

### Step 4: TEST SUITE
Run all automated tests:
1. **Vitest build-gate tests** — unit/integration (T04-T13)
2. **Playwright E2E tests** — browser tests (T01-T02)
3. **Custom scripts** — memory leak (T03), CPU spike (T14) [full mode only]
Any test failure = immediate FAIL.

### Step 5: REVIEWER AGENT [full mode only]
Spawn an independent `reviewer` subagent (read-only, separate context):
- Reviewer receives: test results JSON, build log, stability metrics
- Reviewer checks: test coverage gaps, suspicious patterns, result consistency
- Reviewer outputs: APPROVED or REJECTED with findings
- Must not share context with the builder agent

```
Launch a reviewer agent with subagent_type="reviewer" and provide it:
1. The contents of build-gate-report.json
2. The server console output from the stability monitor
3. Ask it to verify: all steps passed, no suspicious patterns, results consistent
4. The reviewer must output APPROVED or REJECTED with reasoning
```

### Step 6: FINAL VERIFICATION
Aggregate all results into `build-gate-report.json`:
- All steps PASS + reviewer APPROVED = **READY**
- Any step FAIL or reviewer REJECTED = **NOT READY**
- Kill the dev server process
- Print summary to console

## Modes

| Mode | Steps | Duration | Trigger |
|------|-------|----------|---------|
| **Quick** | 1, 2, 4 (vitest only), 6 | ~2 min | Pre-push hook, `npm run build-gate:quick` |
| **Full** | All 6 | ~8-10 min | Manual, `/build-gate` skill, `npm run build-gate` |

## Commands

```bash
npm run build-gate          # Full pipeline (all 6 steps)
npm run build-gate:quick    # Quick pipeline (pre-push speed)
npm run test:build-gate     # Just the vitest build-gate tests
npm run test:stability      # Just the 5-min stability monitor
```

## Test Registry (15 Tests)

| ID | Name | Runner | Category |
|----|------|--------|----------|
| T01 | Cold Start Boot | Playwright | Integration |
| T02 | Hot Reload Stability | Playwright | Runtime |
| T03 | Memory Leak Detection | Script | Performance |
| T04 | Unhandled Exception Traps | Vitest | Error Handling |
| T05 | File Watcher Config | Vitest | Event-Driven |
| T06 | Concurrent Request Handling | Vitest | Concurrency |
| T07 | DI Contract Integrity | Vitest | Architecture |
| T08 | Configuration Validation | Vitest | Config |
| T09 | Structured Logging | Vitest | Logging |
| T10 | Crash Recovery | Vitest | Resilience |
| T11 | API Contract Validation | Vitest | Integration |
| T12 | State Persistence | Vitest | Data Integrity |
| T13 | Security Boundary Checks | Vitest | Security |
| T14 | CPU Spike Handling | Script | Performance |
| T15 | Long-Running Stability | Script | Stability |

## Success Criteria

- All tests passed
- Runtime stable for 5 minutes (full mode)
- No unhandled errors
- Reviewer agent approved (full mode)
- Memory growth < 50% of baseline
- CPU recovers after load spike (>80% success rate)

## Failure policy: repair, do not report

A failing step means the work is not finished. It does not mean the run is finished. Never print READY while a step fails, but also never hand a list of failures back to the user when you could have fixed them: a failure report costs the user a round trip, a repaired gate does not.

1. Stop the pipeline at the failing step, record the detail, and classify it: PRODUCT (real defect), HARNESS (the gate script or a test expectation is wrong), UNEXPLAINED (not yet understood), or OWNER (cannot be fixed from here: usage quota, hardware, credentials, an approval the user has not given).
2. Repair every PRODUCT, HARNESS and UNEXPLAINED failure now, following `references/fix-loop.md`: fix, re-run only the failed steps, repeat for at most 3 rounds. Investigating an UNEXPLAINED failure (run it alone, read its log) is part of the work; it is not a reason to stop.
3. Only OWNER failures may end the run unfixed, and each one is reported with what was tried and the single action the user must take.
4. Write `build-gate-report.json` (fields in `references/fix-loop.md`) after every round, including `head` (the commit gated), `verdict`, and per-step `failure_class`. The stop hook in `references/activation.md` reads it.

When you report back, lead with the outcome: READY at commit X, what changed, the evidence. List only OWNER blockers, then optional follow-ups. Do not open with failures that you already fixed.

## When the gate must run (do not wait to be asked)

Treat the gate as the definition of done. Run it, in full or as quick mode, at each of these moments:

- after integrating, merging or cherry-picking work, and whenever a subagent returns code;
- before any push of code changes, before telling the user the work is done, and before writing a handoff;
- after any change to the gate script itself, and after fixing a failure (only the failed steps).

Put the same instruction into every subagent brief you write ("run lint and your tests, fix failures, return only when green or blocked on the owner") and into the project's CLAUDE.md. `references/activation.md` has the exact text and an optional stop hook that enforces it.

## Adapting the gate to the project

The steps above assume `npm run build`, Vitest and Playwright scripts. Many projects have none of them. Do not skip a step; map it to what the project really has and write the mapping down at the top of the report, so a reader can see what "pass" meant.

| Step | Typical equivalent when no build script exists |
|---|---|
| 1 Build | linter + container image build (or `node --check` over sources) |
| 2 Launch | start the server (in the sandbox below) and wait for the health endpoint |
| 3 Stability | health every 30 s, memory growth, log scan for real errors, event stream or WebSocket still connected |
| 4 Tests | every test script the project defines, plus a browser sweep of each UI tab and an adversarial API script |
| 5 Reviewer | unchanged: separate context, results only |

For code that has not been run before, or that comes from an agent, run steps 2 to 4 in the offline container sandbox described in `references/sandboxed-mode.md` instead of on the host.

## Gate-script hygiene (read before trusting a failure)

Gate scripts are code and they have bugs. Several real failures in one project were the script, not the product. Before reporting NOT READY, classify each failure as PRODUCT, HARNESS or UNEXPLAINED and put the class in `build-gate-report.json` (`failure_class`). The verdict is still NOT READY while any failure stands, but the classification decides what you fix first.

- Log scans must not match their own startup lines. A grep for `unhandled` matched the line "Process handlers registered (uncaughtException, unhandledRejection)". Anchor on the log level or exception format, or exclude registration lines.
- Resolve browser tooling explicitly. "Cannot find module playwright" means the module path is wrong (for global installs use the output of `npm root -g` as `NODE_PATH`); that is a HARNESS failure and the browser checks did not run, so they count as NOT RUN, not as passed.
- Update expectations when a fix deliberately changes behaviour. A rate-limit test that bursts 70 requests fails after the limit is raised on purpose; change the test and note why.
- A test that passed before and now times out is UNEXPLAINED. Run it alone, with the same environment, before blaming the change.
- An idle server may legitimately send no WebSocket or SSE messages. Record the count, but only fail on disconnects or errors unless the project promises heartbeats.
- Run the full gate once per candidate. After a repair, re-run only the failed steps; the full gate runs again once at the end if the repairs touched shared code. Looping the full gate burns time and, with agents involved, budget.
- The reviewer agent gets results and logs only, never the builder's conversation. Using a stronger model for this one step is worth it; using it for every step is not.

## Helper scripts (use them instead of reasoning from scratch)
- `scripts/classify_failure.py LOG [--was-passing]` maps a failing step's log to PRODUCT / HARNESS / UNEXPLAINED / OWNER with the known repair (data in `references/repair-catalogue.json`; add an entry whenever a new harness failure is solved).
- `scripts/bisect_regression.sh GOOD_SHA "CMD"` finds the commit that broke a command, in a throwaway worktree.
- `scripts/gate_stop_hook.sh` keeps the session from stopping on a fixable failure.
- After a green gate run the `work-preservation` checkpoint so the verified head is on the remote.
- `references/reference-gate.sh`: a working end-to-end gate script (Docker offline sandbox, stability, suite, browser sweep, attack tests, report) from the BrightForge project; copy and adapt it.
