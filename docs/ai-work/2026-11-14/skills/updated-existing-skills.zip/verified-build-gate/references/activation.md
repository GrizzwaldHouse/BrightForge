
# Making agents run the gate at the right times

A skill that is only described is easily skipped, and subagents never see it unless told. Three layers, strongest last. Use the first two always; add the hook when a project keeps ending turns with known failures.

## 1. Project CLAUDE.md block (reaches every agent, including subagents)

```markdown
## Definition of done
Work is not done, and must not be reported as done or handed off, until the build gate
(skill `verified-build-gate`, script `test/clean-room/gate.sh`) says READY for the current HEAD.
- Run it after integrating branches or receiving subagent code, before pushing code, and before a handoff.
- When a step fails, do not stop and report. Classify it (PRODUCT, HARNESS, UNEXPLAINED, OWNER), fix it,
  re-run only the failed steps, at most 3 rounds.
- Report outcome first: READY at <commit> and the evidence. Mention only OWNER blockers
  (quota, hardware, credentials, approvals) and what you need from the owner.
```

## 2. Subagent and workflow briefs

Add to every implementer brief: "Before returning, run lint and your tests and fix failures. Return only when everything you were asked to deliver is green, or when blocked on the owner (say exactly what you need)." Add a final workflow stage that runs the gate and the fix loop, so success is produced by the pipeline, not reported afterwards.

## 3. Optional stop hook (blocks stopping while a known fixable failure stands)

Copy `scripts/gate_stop_hook.sh` to `.claude/hooks/gate-stop-hook.sh` (executable) and register it in `.claude/settings.json`:

```json
{
  "hooks": {
    "Stop": [
      { "hooks": [ { "type": "command", "command": "\"$CLAUDE_PROJECT_DIR\"/.claude/hooks/gate-stop-hook.sh" } ] }
    ]
  }
}
```

The hook reads `.gate/build-gate-report.json`. It lets the agent stop when there is no report, when the verdict is READY, when the report is for an older commit, or when every failure is class OWNER. Otherwise it blocks (exit 2) with the failing steps and tells the agent to run the fix loop. It blocks at most 3 times per commit, so a stuck gate cannot trap a session or burn budget forever. Add `.gate/` to `.gitignore`.
