# Sandboxed mode: run unproven code offline in a container

Use for steps 2 to 4 when the code is new, agent-written, or the host holds things you cannot lose. Nothing here needs the project to change.

## Source
Build from a snapshot of a pinned commit, never from a working copy: `git archive <commit> | tar -x -C <empty dir>`. Record the commit and the hashes of the lockfile, Dockerfile and compose file. The snapshot has no `.env` files; check with `find`.

## Build
- Daemon not running (cloud containers lose it on restart): `nohup dockerd > dockerd.log 2>&1 &`, then wait for `docker info`.
- Behind a TLS-intercepting proxy, pass the CA as a BuildKit secret, never an argument: `docker build --network host --secret id=extra_ca,src=<ca bundle> --build-arg HTTP_PROXY=... --target test -t app-test:local .` (the Dockerfile reads `/run/secrets/extra_ca` only inside one RUN step).
- After building, `docker history --no-trunc <image>` must show no proxy URL and no certificate text. Count the matches; the gate fails on a non-zero count.
- Pin base images by digest; run as a non-root user.

## Run test suites (no network)
`network_mode: none`, `read_only: true`, non-root `user`, `cap_drop: ["ALL"]`, `security_opt: ["no-new-privileges:true"]`, tmpfs for the few writable directories, and limits for pids, memory and CPU. No host mounts, no Docker socket, no real credentials. Compare counts against the previous run: a new test script is expected, a missing one is not.

## Run the server and the browser checks
- Put the server on an internal Docker network (`docker network create --internal`) so it has no internet. Check it: an outbound fetch from inside must fail.
- If the app binds to loopback only, start a sidecar in the same network namespace (`--network container:<server>`) that forwards a port to it, so the host-side browser can reach it. The same sidecar can host a fake model provider on the loopback address the app expects, with switchable modes: ok, slow (never answers), malformed, empty, http500, prose instead of the expected format, and hostile output such as `../` file paths.
- Browser sweep: click every tab, record each `/api/*` call with status, console errors and page errors, take a screenshot, and block every host except the server (list the hosts the page tried). Real output beats a rendered tab: also drive one end-to-end flow (prompt, review, approve, file on disk).
- Idle polling: leave a tab open for 90 to 150 s and compute requests per minute against the rate limit. Rapid tab switching is a separate, noisier case.

## Adversarial API checks (each recorded PASS/FAIL with the observed value)
Missing and wrong-typed fields; malformed JSON without a stack trace; oversized body returns 413; identifiers with `../` and SQL-like text; options such as `--help` and very long input in any parameter that reaches a shell or git; model output that proposes paths outside the project (read AND write); provider failures and timeouts return an error without crashing; cancel mid-generation; SSE client disconnect; two concurrent sessions stay isolated; a burst over the rate limit; bounded load (about 300 requests, 10 at a time, record p50/p95); auth boundaries with a key set (no key, wrong key, right key, spoofed forwarding headers, WebSocket); graceful shutdown with a request in flight (response arrives, exit code 0).
