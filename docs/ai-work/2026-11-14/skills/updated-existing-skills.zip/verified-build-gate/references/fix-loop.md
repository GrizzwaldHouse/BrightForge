
# Fix loop

Goal: turn a failing gate into READY without a round trip to the user. Maximum 3 rounds; each round repairs everything that is repairable, then re-runs only the steps that failed.

## Round procedure

1. Read the failing step's log, not just its one-line detail.
2. Classify (see below) and fix. Batch independent repairs in the same round.
3. Re-run the failed steps only. If a repair touched code that earlier steps depend on, also re-run those steps.
4. Update the report. If still failing after round 3, stop and report what was tried, the evidence, and your best explanation; that is the only case where a repairable failure is reported unfixed.

## Classes and what to do

| Class | Meaning | Action |
|---|---|---|
| PRODUCT | the application is wrong | write a failing test if there is none, fix the code, re-run |
| HARNESS | the gate script, test helper or expectation is wrong | fix the script/test, say why in the commit; never loosen a check just to pass (the old expectation must be shown to be stale) |
| UNEXPLAINED | cause unknown | run the step alone with the same environment, read its log, bisect against the last green commit; it becomes PRODUCT or HARNESS once understood |
| OWNER | needs the user: quota, paid credit, hardware (GPU), credentials, approval, a machine that is offline | stop on this one only; state the one action needed |

## Repair catalogue (known causes)

| Symptom | Likely class | Repair |
|---|---|---|
| log scan counts "unhandled" and the matched line is a startup message such as "Process handlers registered" | HARNESS | anchor the pattern on error format (`^\[?(ERROR|FATAL)`, `UnhandledPromiseRejection`, `Unhandled rejection at`) and exclude registration lines |
| "Cannot find module playwright" (or another global tool) | HARNESS | set `NODE_PATH=$(npm root -g)` or install it in the gate's own directory; the checks did not run, so re-run them |
| rate-limit burst test no longer sees 429 after the limit was raised on purpose | HARNESS | burst past the new limit, or test from a non-exempt peer; keep a test that the limit still exists |
| a test that used to pass in seconds now times out | UNEXPLAINED | run it alone with a short timeout; look for an open handle, a network call that no longer fails fast, or a changed environment variable |
| test helper sends a header or flag that production code now ignores unless an env var is set | HARNESS | set the env var in the helper's server start, not in production code |
| old test asserts behaviour the fix deliberately changed | HARNESS | update the assertion with the reason; confirm the new behaviour has its own test |
| docker daemon down / base image pull rate limited | HARNESS | start the daemon (`nohup dockerd`); pin a mirrored image digest; retry once |
| browser sweep shows 429s | PRODUCT or HARNESS | decide from the rate-limit config and request counts, then fix the limiter or the sweep pacing |

## Report fields

```json
{
  "head": "<commit sha gated>",
  "verdict": "READY | NOT READY",
  "round": 2,
  "mapping": "what each step meant for this project",
  "steps": [
    {"step": 4, "name": "tests", "result": "PASS | FAIL | NOT RUN",
     "failure_class": "PRODUCT | HARNESS | UNEXPLAINED | OWNER | null",
     "detail": "...", "fixed_in": "<commit>"}
  ],
  "reviewer": "APPROVED | REJECTED | NOT RUN"
}
```
NOT RUN counts as a failure for the verdict (a step that did not execute proves nothing).
