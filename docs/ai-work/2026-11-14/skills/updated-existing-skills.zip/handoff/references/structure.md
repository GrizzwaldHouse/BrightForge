# handoff.md structure

Keep each section short. Tables beat prose for state and open items. Target 100-150 lines.

1. **State in one paragraph.** Branch, what is merged or not, gate verdict (READY / NOT READY), what is blocked and by whom. A reader who stops here should still know the situation.
2. **Repository facts (table).** Repo, working branch, baseline commit, last fully verified tip, remote tip versus local tip, branches or tags that exist only locally, anything pushed this session, branches deliberately untouched (main).
3. **What was done (table).** Area, result, evidence (document path or commit). One line each.
4. **Verification status (table).** Each check with result. Lead with what is verified and READY. A failure that is still listed must be classified (PRODUCT, HARNESS, UNEXPLAINED, OWNER) and must show what was already tried; fixable failures should have been fixed before this document was written, so a long failure list here is a sign the fix loop was skipped.
5. **Open work.** IDs that match the spec or issue tracker, one line of cause, file and line where known, and whether the finding was verified against the source or only reported by a reviewer.
6. **Needs the owner.** Approvals, quotas, hardware, machines that were offline, decisions not yet made. Name the exact command or setting where possible.
7. **Cost lessons.** What consumed the budget (agent counts, tokens, repeated builds), what hit a usage limit, and the cheaper plan for next time.
8. **Environment notes.** Things that bite on restart: daemons that must be started, required build flags, scratch paths that disappear, credential storage (names only).
9. **Resume plan.** Ordered, cheapest first: fix the harness before blaming the code, rerun only what failed, then new work.
10. **Starter prompt.** A paste-in block for the new session: branch, the file to read first, the order of work, hard limits (no merge to main, no pushes to other branches, no AI attribution in commits, no secrets), agent-count limits, and what needs approval first.
11. **Suggested skills.** Skills the next agent should load.
