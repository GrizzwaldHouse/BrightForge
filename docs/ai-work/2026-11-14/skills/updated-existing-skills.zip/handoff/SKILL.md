---
name: handoff
description: Compact the current conversation into a handoff document (handoff.md) for another agent or a fresh session to pick up. Use when the user says handoff, write-off report, continue in a new session, context is getting long, or usage limit is close. Records verified state, failures classified by cause, open work with IDs, owner-only decisions, usage-cost lessons and a paste-in starter prompt.
argument-hint: "What will the next session be used for?"
disable-model-invocation: true
---

Write a handoff document summarising the current conversation so a fresh agent can continue the work. Name the file `handoff.md`.

Save it under `C:\AgentForge-Control\06_HANDOFFS\<project-or-system>\<date-or-run-id>\` — not the OS temp directory, and not the current workspace. Use today's date (YYYY-MM-DD) for `<date-or-run-id>` unless a more specific run id is already in play, and pick `<project-or-system>` from the current working directory or task context. Create the destination folder if it doesn't exist yet. If the user asks for the handoff inside the repository (or the work lives in a git repo and the user wants it versioned), put `handoff.md` at the repo root instead and commit it to the working branch they already approved for pushes.

Build the document from `references/structure.md`: it lists the sections that made earlier handoffs resumable (state in one paragraph, repo facts, verification status with failures classified by cause, open work with IDs, things only the owner can do, cost lessons, environment gotchas, an ordered resume plan, and the starter prompt). Read it before writing.

Rules that keep a handoff honest:

- A handoff is not a place to park fixable failures. Before writing one, run the verified-build-gate fix loop on anything PRODUCT, HARNESS or UNEXPLAINED and fix it; the document should open with what is verified and READY, and list as open work only what the owner must do (quota, hardware, credentials, approvals) or what ran out of budget, with what was already tried. If you are writing the handoff because the budget is nearly gone, say so and put the cheapest next fix first.

- Say where each piece of work physically lives. Scratch worktrees, containers and local branches vanish with the session. If something exists only locally, either preserve it (push it to the branch the user approved, or copy small evidence into the handoff folder) or flag it clearly as unpushed. A handoff that points at paths which will no longer exist is worse than none.
- Report what was run, not what was intended. Mark anything not executed as NOT RUN, and say why. Check numbers a subagent reported against the files before repeating them.
- Do not duplicate content already captured in other artifacts (specs, plans, ADRs, issues, commits, diffs). Reference them by path, URL or commit hash instead.
- Redact any sensitive information, such as API keys, passwords, or personally identifiable information. Say which credentials exist and where they are stored, never their values.
- Include a "suggested skills" section naming which skills the next agent should call the Skill tool for.

If the user passed arguments, treat them as a description of what the next session will focus on and tailor the doc accordingly.
